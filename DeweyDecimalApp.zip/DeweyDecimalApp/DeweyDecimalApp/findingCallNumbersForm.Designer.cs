﻿namespace DeweyDecimalApp
{
    partial class findingCallNumbersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_help = new System.Windows.Forms.Button();
            this.lbl_question = new System.Windows.Forms.Label();
            this.cmb_userAnswer = new System.Windows.Forms.ComboBox();
            this.btn_Submit = new System.Windows.Forms.Button();
            this.lbl_totalScore = new System.Windows.Forms.Label();
            this.lbl_subheader = new System.Windows.Forms.Label();
            this.lbl_header = new System.Windows.Forms.Label();
            this.lbl_ques = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Cascadia Code", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_back.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btn_back.Location = new System.Drawing.Point(12, 12);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(68, 37);
            this.btn_back.TabIndex = 1;
            this.btn_back.Text = "<Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_help
            // 
            this.btn_help.Font = new System.Drawing.Font("Symbol", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_help.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btn_help.Location = new System.Drawing.Point(434, 182);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(35, 65);
            this.btn_help.TabIndex = 66;
            this.btn_help.Text = "?";
            this.btn_help.UseVisualStyleBackColor = true;
            this.btn_help.Click += new System.EventHandler(this.btn_help_Click);
            // 
            // lbl_question
            // 
            this.lbl_question.AutoSize = true;
            this.lbl_question.BackColor = System.Drawing.Color.Transparent;
            this.lbl_question.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_question.Location = new System.Drawing.Point(253, 150);
            this.lbl_question.Name = "lbl_question";
            this.lbl_question.Size = new System.Drawing.Size(91, 20);
            this.lbl_question.TabIndex = 67;
            this.lbl_question.Text = "lbl_question";
            // 
            // cmb_userAnswer
            // 
            this.cmb_userAnswer.FormattingEnabled = true;
            this.cmb_userAnswer.Location = new System.Drawing.Point(253, 182);
            this.cmb_userAnswer.Name = "cmb_userAnswer";
            this.cmb_userAnswer.Size = new System.Drawing.Size(175, 28);
            this.cmb_userAnswer.TabIndex = 68;
            // 
            // btn_Submit
            // 
            this.btn_Submit.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Submit.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btn_Submit.Location = new System.Drawing.Point(150, 182);
            this.btn_Submit.Name = "btn_Submit";
            this.btn_Submit.Size = new System.Drawing.Size(94, 29);
            this.btn_Submit.TabIndex = 69;
            this.btn_Submit.Text = "Submit";
            this.btn_Submit.UseVisualStyleBackColor = true;
            this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
            // 
            // lbl_totalScore
            // 
            this.lbl_totalScore.AutoSize = true;
            this.lbl_totalScore.BackColor = System.Drawing.Color.Transparent;
            this.lbl_totalScore.Font = new System.Drawing.Font("Impact", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_totalScore.Location = new System.Drawing.Point(150, 219);
            this.lbl_totalScore.Name = "lbl_totalScore";
            this.lbl_totalScore.Size = new System.Drawing.Size(139, 28);
            this.lbl_totalScore.TabIndex = 70;
            this.lbl_totalScore.Text = "Your Points: 0";
            // 
            // lbl_subheader
            // 
            this.lbl_subheader.AutoSize = true;
            this.lbl_subheader.BackColor = System.Drawing.Color.Transparent;
            this.lbl_subheader.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_subheader.Location = new System.Drawing.Point(132, 58);
            this.lbl_subheader.Name = "lbl_subheader";
            this.lbl_subheader.Size = new System.Drawing.Size(314, 27);
            this.lbl_subheader.TabIndex = 72;
            this.lbl_subheader.Text = "Finding Call Numbers Quiz!";
            // 
            // lbl_header
            // 
            this.lbl_header.AutoSize = true;
            this.lbl_header.BackColor = System.Drawing.Color.Transparent;
            this.lbl_header.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_header.Location = new System.Drawing.Point(97, 12);
            this.lbl_header.Name = "lbl_header";
            this.lbl_header.Size = new System.Drawing.Size(392, 38);
            this.lbl_header.TabIndex = 71;
            this.lbl_header.Text = "Dewey Decimal System";
            // 
            // lbl_ques
            // 
            this.lbl_ques.AutoSize = true;
            this.lbl_ques.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ques.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_ques.Location = new System.Drawing.Point(12, 109);
            this.lbl_ques.Name = "lbl_ques";
            this.lbl_ques.Size = new System.Drawing.Size(604, 25);
            this.lbl_ques.TabIndex = 73;
            this.lbl_ques.Text = "Question 1: Which top-layer category does the description belong to?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(150, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 20);
            this.label1.TabIndex = 74;
            this.label1.Text = "Description: ";
            // 
            // findingCallNumbersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DeweyDecimalApp.Properties.Resources.qw_t;
            this.ClientSize = new System.Drawing.Size(632, 278);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_ques);
            this.Controls.Add(this.lbl_subheader);
            this.Controls.Add(this.lbl_header);
            this.Controls.Add(this.lbl_totalScore);
            this.Controls.Add(this.btn_Submit);
            this.Controls.Add(this.cmb_userAnswer);
            this.Controls.Add(this.lbl_question);
            this.Controls.Add(this.btn_help);
            this.Controls.Add(this.btn_back);
            this.Name = "findingCallNumbersForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "findingCallNumbersForm";
            this.Load += new System.EventHandler(this.findingCallNumbersForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_back;
        private Button btn_help;
        private Label lbl_question;
        private ComboBox cmb_userAnswer;
        private Button btn_Submit;
        private Label lbl_totalScore;
        private Label lbl_subheader;
        private Label lbl_header;
        private Label lbl_ques;
        private Label label1;
    }
}