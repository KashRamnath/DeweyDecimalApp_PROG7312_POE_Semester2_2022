﻿namespace DeweyDecimalApp
{
    partial class identifyingAreasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_back = new System.Windows.Forms.Button();
            this.lbl_callNum1 = new System.Windows.Forms.Label();
            this.lbl_callNum2 = new System.Windows.Forms.Label();
            this.lbl_callNum3 = new System.Windows.Forms.Label();
            this.lbl_callNum4 = new System.Windows.Forms.Label();
            this.lbl_descrip1 = new System.Windows.Forms.Label();
            this.lbl_descrip2 = new System.Windows.Forms.Label();
            this.lbl_descrip3 = new System.Windows.Forms.Label();
            this.lbl_descrip4 = new System.Windows.Forms.Label();
            this.lbl_descrip5 = new System.Windows.Forms.Label();
            this.lbl_descrip6 = new System.Windows.Forms.Label();
            this.lbl_descrip7 = new System.Windows.Forms.Label();
            this.lbl_subheader = new System.Windows.Forms.Label();
            this.lbl_header = new System.Windows.Forms.Label();
            this.cmb_Answer1 = new System.Windows.Forms.ComboBox();
            this.cmb_Answer2 = new System.Windows.Forms.ComboBox();
            this.cmb_Answer3 = new System.Windows.Forms.ComboBox();
            this.cmb_Answer4 = new System.Windows.Forms.ComboBox();
            this.lbl_columnA = new System.Windows.Forms.Label();
            this.lbl_columnB = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_callNum7 = new System.Windows.Forms.Label();
            this.lbl_callNum6 = new System.Windows.Forms.Label();
            this.lbl_callNum5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_submit = new System.Windows.Forms.Button();
            this.lbl_points = new System.Windows.Forms.Label();
            this.btn_help = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Cascadia Code", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_back.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btn_back.Location = new System.Drawing.Point(12, 12);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(68, 37);
            this.btn_back.TabIndex = 0;
            this.btn_back.Text = "<Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // lbl_callNum1
            // 
            this.lbl_callNum1.AutoSize = true;
            this.lbl_callNum1.Location = new System.Drawing.Point(6, 38);
            this.lbl_callNum1.Name = "lbl_callNum1";
            this.lbl_callNum1.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum1.TabIndex = 1;
            this.lbl_callNum1.Text = "Philosophy and Psychology";
            // 
            // lbl_callNum2
            // 
            this.lbl_callNum2.AutoSize = true;
            this.lbl_callNum2.Location = new System.Drawing.Point(6, 72);
            this.lbl_callNum2.Name = "lbl_callNum2";
            this.lbl_callNum2.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum2.TabIndex = 2;
            this.lbl_callNum2.Text = "Philosophy and Psychology";
            // 
            // lbl_callNum3
            // 
            this.lbl_callNum3.AutoSize = true;
            this.lbl_callNum3.Location = new System.Drawing.Point(6, 106);
            this.lbl_callNum3.Name = "lbl_callNum3";
            this.lbl_callNum3.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum3.TabIndex = 3;
            this.lbl_callNum3.Text = "Philosophy and Psychology";
            // 
            // lbl_callNum4
            // 
            this.lbl_callNum4.AutoSize = true;
            this.lbl_callNum4.Location = new System.Drawing.Point(6, 140);
            this.lbl_callNum4.Name = "lbl_callNum4";
            this.lbl_callNum4.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum4.TabIndex = 4;
            this.lbl_callNum4.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip1
            // 
            this.lbl_descrip1.AutoSize = true;
            this.lbl_descrip1.Location = new System.Drawing.Point(5, 38);
            this.lbl_descrip1.Name = "lbl_descrip1";
            this.lbl_descrip1.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip1.TabIndex = 5;
            this.lbl_descrip1.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip2
            // 
            this.lbl_descrip2.AutoSize = true;
            this.lbl_descrip2.Location = new System.Drawing.Point(5, 72);
            this.lbl_descrip2.Name = "lbl_descrip2";
            this.lbl_descrip2.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip2.TabIndex = 6;
            this.lbl_descrip2.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip3
            // 
            this.lbl_descrip3.AutoSize = true;
            this.lbl_descrip3.Location = new System.Drawing.Point(5, 108);
            this.lbl_descrip3.Name = "lbl_descrip3";
            this.lbl_descrip3.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip3.TabIndex = 7;
            this.lbl_descrip3.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip4
            // 
            this.lbl_descrip4.AutoSize = true;
            this.lbl_descrip4.Location = new System.Drawing.Point(5, 140);
            this.lbl_descrip4.Name = "lbl_descrip4";
            this.lbl_descrip4.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip4.TabIndex = 8;
            this.lbl_descrip4.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip5
            // 
            this.lbl_descrip5.AutoSize = true;
            this.lbl_descrip5.Location = new System.Drawing.Point(5, 172);
            this.lbl_descrip5.Name = "lbl_descrip5";
            this.lbl_descrip5.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip5.TabIndex = 9;
            this.lbl_descrip5.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip6
            // 
            this.lbl_descrip6.AutoSize = true;
            this.lbl_descrip6.Location = new System.Drawing.Point(5, 204);
            this.lbl_descrip6.Name = "lbl_descrip6";
            this.lbl_descrip6.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip6.TabIndex = 10;
            this.lbl_descrip6.Text = "Philosophy and Psychology";
            // 
            // lbl_descrip7
            // 
            this.lbl_descrip7.AutoSize = true;
            this.lbl_descrip7.Location = new System.Drawing.Point(5, 236);
            this.lbl_descrip7.Name = "lbl_descrip7";
            this.lbl_descrip7.Size = new System.Drawing.Size(188, 20);
            this.lbl_descrip7.TabIndex = 11;
            this.lbl_descrip7.Text = "Philosophy and Psychology";
            // 
            // lbl_subheader
            // 
            this.lbl_subheader.AutoSize = true;
            this.lbl_subheader.BackColor = System.Drawing.Color.Transparent;
            this.lbl_subheader.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_subheader.Location = new System.Drawing.Point(172, 61);
            this.lbl_subheader.Name = "lbl_subheader";
            this.lbl_subheader.Size = new System.Drawing.Size(308, 29);
            this.lbl_subheader.TabIndex = 39;
            this.lbl_subheader.Text = "Identifying Areas Game!";
            // 
            // lbl_header
            // 
            this.lbl_header.AutoSize = true;
            this.lbl_header.BackColor = System.Drawing.Color.Transparent;
            this.lbl_header.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_header.Location = new System.Drawing.Point(138, 11);
            this.lbl_header.Name = "lbl_header";
            this.lbl_header.Size = new System.Drawing.Size(392, 38);
            this.lbl_header.TabIndex = 38;
            this.lbl_header.Text = "Dewey Decimal System";
            // 
            // cmb_Answer1
            // 
            this.cmb_Answer1.FormattingEnabled = true;
            this.cmb_Answer1.Location = new System.Drawing.Point(255, 145);
            this.cmb_Answer1.Name = "cmb_Answer1";
            this.cmb_Answer1.Size = new System.Drawing.Size(186, 28);
            this.cmb_Answer1.TabIndex = 51;
            // 
            // cmb_Answer2
            // 
            this.cmb_Answer2.FormattingEnabled = true;
            this.cmb_Answer2.Location = new System.Drawing.Point(255, 179);
            this.cmb_Answer2.Name = "cmb_Answer2";
            this.cmb_Answer2.Size = new System.Drawing.Size(186, 28);
            this.cmb_Answer2.TabIndex = 52;
            // 
            // cmb_Answer3
            // 
            this.cmb_Answer3.FormattingEnabled = true;
            this.cmb_Answer3.Location = new System.Drawing.Point(255, 213);
            this.cmb_Answer3.Name = "cmb_Answer3";
            this.cmb_Answer3.Size = new System.Drawing.Size(186, 28);
            this.cmb_Answer3.TabIndex = 53;
            // 
            // cmb_Answer4
            // 
            this.cmb_Answer4.FormattingEnabled = true;
            this.cmb_Answer4.Location = new System.Drawing.Point(255, 247);
            this.cmb_Answer4.Name = "cmb_Answer4";
            this.cmb_Answer4.Size = new System.Drawing.Size(186, 28);
            this.cmb_Answer4.TabIndex = 54;
            // 
            // lbl_columnA
            // 
            this.lbl_columnA.AutoSize = true;
            this.lbl_columnA.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_columnA.Location = new System.Drawing.Point(46, 4);
            this.lbl_columnA.Name = "lbl_columnA";
            this.lbl_columnA.Size = new System.Drawing.Size(109, 21);
            this.lbl_columnA.TabIndex = 55;
            this.lbl_columnA.Text = "COLUMN A";
            // 
            // lbl_columnB
            // 
            this.lbl_columnB.AutoSize = true;
            this.lbl_columnB.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_columnB.Location = new System.Drawing.Point(50, 4);
            this.lbl_columnB.Name = "lbl_columnB";
            this.lbl_columnB.Size = new System.Drawing.Size(109, 21);
            this.lbl_columnB.TabIndex = 56;
            this.lbl_columnB.Text = "COLUMN B";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Snow;
            this.panel1.Controls.Add(this.lbl_columnB);
            this.panel1.Controls.Add(this.lbl_descrip1);
            this.panel1.Controls.Add(this.lbl_descrip2);
            this.panel1.Controls.Add(this.lbl_descrip3);
            this.panel1.Controls.Add(this.lbl_descrip4);
            this.panel1.Controls.Add(this.lbl_descrip5);
            this.panel1.Controls.Add(this.lbl_descrip6);
            this.panel1.Controls.Add(this.lbl_descrip7);
            this.panel1.Location = new System.Drawing.Point(447, 110);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 260);
            this.panel1.TabIndex = 57;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Snow;
            this.panel2.Controls.Add(this.lbl_callNum7);
            this.panel2.Controls.Add(this.lbl_callNum6);
            this.panel2.Controls.Add(this.lbl_callNum5);
            this.panel2.Controls.Add(this.lbl_columnA);
            this.panel2.Controls.Add(this.lbl_callNum1);
            this.panel2.Controls.Add(this.lbl_callNum2);
            this.panel2.Controls.Add(this.lbl_callNum3);
            this.panel2.Controls.Add(this.lbl_callNum4);
            this.panel2.Location = new System.Drawing.Point(12, 110);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 260);
            this.panel2.TabIndex = 58;
            // 
            // lbl_callNum7
            // 
            this.lbl_callNum7.AutoSize = true;
            this.lbl_callNum7.Location = new System.Drawing.Point(6, 236);
            this.lbl_callNum7.Name = "lbl_callNum7";
            this.lbl_callNum7.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum7.TabIndex = 58;
            this.lbl_callNum7.Text = "Philosophy and Psychology";
            // 
            // lbl_callNum6
            // 
            this.lbl_callNum6.AutoSize = true;
            this.lbl_callNum6.Location = new System.Drawing.Point(6, 204);
            this.lbl_callNum6.Name = "lbl_callNum6";
            this.lbl_callNum6.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum6.TabIndex = 57;
            this.lbl_callNum6.Text = "Philosophy and Psychology";
            // 
            // lbl_callNum5
            // 
            this.lbl_callNum5.AutoSize = true;
            this.lbl_callNum5.Location = new System.Drawing.Point(6, 172);
            this.lbl_callNum5.Name = "lbl_callNum5";
            this.lbl_callNum5.Size = new System.Drawing.Size(188, 20);
            this.lbl_callNum5.TabIndex = 56;
            this.lbl_callNum5.Text = "Philosophy and Psychology";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Bauhaus 93", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(218, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 19);
            this.label1.TabIndex = 59;
            this.label1.Text = ">>";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bauhaus 93", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(218, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 19);
            this.label2.TabIndex = 60;
            this.label2.Text = ">>";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Bauhaus 93", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(218, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 19);
            this.label3.TabIndex = 61;
            this.label3.Text = ">>";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Bauhaus 93", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(218, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 19);
            this.label4.TabIndex = 62;
            this.label4.Text = ">>";
            // 
            // btn_submit
            // 
            this.btn_submit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_submit.Font = new System.Drawing.Font("Cascadia Mono", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_submit.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btn_submit.Location = new System.Drawing.Point(255, 286);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(186, 48);
            this.btn_submit.TabIndex = 63;
            this.btn_submit.Text = "Submit Answers";
            this.btn_submit.UseVisualStyleBackColor = false;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // lbl_points
            // 
            this.lbl_points.AutoSize = true;
            this.lbl_points.Font = new System.Drawing.Font("Impact", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_points.Location = new System.Drawing.Point(255, 338);
            this.lbl_points.Name = "lbl_points";
            this.lbl_points.Size = new System.Drawing.Size(139, 28);
            this.lbl_points.TabIndex = 64;
            this.lbl_points.Text = "Your Points: 0";
            // 
            // btn_help
            // 
            this.btn_help.Font = new System.Drawing.Font("Symbol", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_help.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btn_help.Location = new System.Drawing.Point(218, 286);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(31, 48);
            this.btn_help.TabIndex = 65;
            this.btn_help.Text = "?";
            this.btn_help.UseVisualStyleBackColor = true;
            this.btn_help.Click += new System.EventHandler(this.btn_help_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label5.Location = new System.Drawing.Point(18, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 66;
            this.label5.Text = "Questions:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label6.Location = new System.Drawing.Point(578, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 17);
            this.label6.TabIndex = 67;
            this.label6.Text = ":Answers";
            // 
            // identifyingAreasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::DeweyDecimalApp.Properties.Resources.qw_t;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(662, 383);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_help);
            this.Controls.Add(this.lbl_points);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cmb_Answer4);
            this.Controls.Add(this.cmb_Answer3);
            this.Controls.Add(this.cmb_Answer2);
            this.Controls.Add(this.cmb_Answer1);
            this.Controls.Add(this.lbl_subheader);
            this.Controls.Add(this.lbl_header);
            this.Controls.Add(this.btn_back);
            this.Name = "identifyingAreasForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "identifyingAreasForm";
            this.Load += new System.EventHandler(this.identifyingAreasForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_back;
        private Label lbl_callNum1;
        private Label lbl_callNum2;
        private Label lbl_callNum3;
        private Label lbl_callNum4;
        private Label lbl_descrip1;
        private Label lbl_descrip2;
        private Label lbl_descrip3;
        private Label lbl_descrip4;
        private Label lbl_descrip5;
        private Label lbl_descrip6;
        private Label lbl_descrip7;
        private Label lbl_subheader;
        private Label lbl_header;
        private ComboBox cmb_Answer1;
        private ComboBox cmb_Answer2;
        private ComboBox cmb_Answer3;
        private ComboBox cmb_Answer4;
        private Label lbl_columnA;
        private Label lbl_columnB;
        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btn_submit;
        private Label lbl_points;
        private Label lbl_callNum7;
        private Label lbl_callNum6;
        private Label lbl_callNum5;
        private Button btn_help;
        private Label label5;
        private Label label6;
    }
}