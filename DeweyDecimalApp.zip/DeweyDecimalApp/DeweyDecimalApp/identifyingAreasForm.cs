﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using DeweyDecimalClassLibrary; //implements Class Library


namespace DeweyDecimalApp
{
    public partial class identifyingAreasForm : Form
    {
        Library library = new Library(); //declares Class Library
        public List<string> listOfAnswers = new List<string>(); //list of answers from library
        public List<int> lstGendNums = new List<int>(); //List of generated numbers
        public List<int> shuffledList = new List<int>(); //List of same generated numbers, shuffled
        public int score = 0; //keeps track of score value
        bool alternateColumns = false; //switches from match call-num to descrip and vice versa

        public identifyingAreasForm()
        {
            InitializeComponent();

            //begins the code process
            prepareCallNumToDescrip();

        }

        //method sequences for matching call-num to descrip
        public void prepareCallNumToDescrip() 
        {
            getAnswerList();

            generateSevenNumbers();

            shuffleGeneratedSevenNumbers();

            displayGeneratedQuestions();

            populateComboboxes();
        }

        //alternate method sequences of matching descrip to call-num
        public void prepareDescripToCallNum()
        {
            getAnswerList();

            generateSevenNumbers();

            shuffleGeneratedSevenNumbers();

            displayAlternateGeneratedQuestions();

            populateAlternateComboboxes();
        }

        //gets the answers list from library and populates list
        public void getAnswerList()
        {
            listOfAnswers.Clear(); //clears prior data

            foreach (string answer in library.answers)
            {
                listOfAnswers.Add(answer);
            }
        }

        //Generates 7 non-reoccuring numbers from 0-10
        public void generateSevenNumbers()
        {
            lstGendNums.Clear(); //clears prior data

            Random random = new Random();

            var rand = new Random();

            int number;

            for(int i = 0; i < 7; i++)
            {
                do
                {
                    number = rand.Next(0, 10);
                }
                while(lstGendNums.Contains(number)); //ensures no numbers are repeated

                lstGendNums.Add(number); //adds to list used for randomizing output

            }
        }

        //Shuffles data in first list and saves to second list
        public void shuffleGeneratedSevenNumbers()
        {
            shuffledList.Clear(); //clears prior data

            shuffledList = lstGendNums.OrderBy(x => Guid.NewGuid()).ToList(); //copies list lstGendNums to list shuffledList and then
                                                                              //randomizes the order of the values
        }

        //When matching the descriptions to call-nums, this is called
        public void displayGeneratedQuestions()
        {
            //prints 4 call-nums as questions
                lbl_callNum1.Text = library.callNumber[lstGendNums[0]];
                lbl_callNum2.Text = library.callNumber[lstGendNums[1]];
                lbl_callNum3.Text = library.callNumber[lstGendNums[2]];
                lbl_callNum4.Text = library.callNumber[lstGendNums[3]];
                lbl_callNum5.Text = "";
                lbl_callNum6.Text = "";
                lbl_callNum7.Text = "";

            //prints 7 descriptions as answers; 3 of which are incorrect
                lbl_descrip1.Text = library.description[shuffledList[0]];
                lbl_descrip2.Text = library.description[shuffledList[1]];
                lbl_descrip3.Text = library.description[shuffledList[2]];
                lbl_descrip4.Text = library.description[shuffledList[3]];
                lbl_descrip5.Text = library.description[shuffledList[4]];
                lbl_descrip6.Text = library.description[shuffledList[5]];
                lbl_descrip7.Text = library.description[shuffledList[6]];

        }

        //When matching the call-nums to descriptions, this is called
        public void displayAlternateGeneratedQuestions()
        {
            //prints 4 descriptions as questions
            lbl_callNum1.Text = library.description[shuffledList[0]];
            lbl_callNum2.Text = library.description[shuffledList[1]];
            lbl_callNum3.Text = library.description[shuffledList[2]];
            lbl_callNum4.Text = library.description[shuffledList[3]];
            lbl_callNum5.Text = "";
            lbl_callNum6.Text = "";
            lbl_callNum7.Text = "";

            //prints 7 call-nums as answers; 3 of which are incorrect
            lbl_descrip1.Text = library.callNumber[lstGendNums[0]];
            lbl_descrip2.Text = library.callNumber[lstGendNums[1]];
            lbl_descrip3.Text = library.callNumber[lstGendNums[2]];
            lbl_descrip4.Text = library.callNumber[lstGendNums[3]];
            lbl_descrip5.Text = library.callNumber[lstGendNums[4]];
            lbl_descrip6.Text = library.callNumber[lstGendNums[5]];
            lbl_descrip7.Text = library.callNumber[lstGendNums[6]];
        }

        //re-populates the comboboxes used as answering inputs
        public void populateComboboxes()
        {
            //clears prior data
            cmb_Answer1.Items.Clear();
            cmb_Answer2.Items.Clear();
            cmb_Answer3.Items.Clear();
            cmb_Answer4.Items.Clear();

            //displays randomized data to each combobox
            foreach (int shuffleditem in shuffledList)
                {
                    //repopulates combobox with new description values
                    cmb_Answer1.Items.Add(library.description[shuffleditem].ToString());
                    cmb_Answer2.Items.Add(library.description[shuffleditem].ToString());
                    cmb_Answer3.Items.Add(library.description[shuffleditem].ToString());
                    cmb_Answer4.Items.Add(library.description[shuffleditem].ToString());
                }
            
        }

        //re-populates the comboboxes used as answering input
        public void populateAlternateComboboxes()
        {
            //clears prior data
            cmb_Answer1.Items.Clear();
            cmb_Answer2.Items.Clear();
            cmb_Answer3.Items.Clear();
            cmb_Answer4.Items.Clear();

            foreach (int lstGendNums in lstGendNums)
            {
                //repopulates combobox with new call-number values
                cmb_Answer1.Items.Add(library.callNumber[lstGendNums].ToString());
                cmb_Answer2.Items.Add(library.callNumber[lstGendNums].ToString());
                cmb_Answer3.Items.Add(library.callNumber[lstGendNums].ToString());
                cmb_Answer4.Items.Add(library.callNumber[lstGendNums].ToString());
            }

        }

        //returns the user to the main menu form
        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenuForm rbf = new MainMenuForm(); //this is the change, code for redirect  
            rbf.ShowDialog();
        }

        //hides control bos on for load
        private void identifyingAreasForm_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
        }

        //activates when user submots their answer
        private void btn_submit_Click(object sender, EventArgs e)
        {
            //exception handling for empty fields
            if (cmb_Answer1.SelectedIndex == -1 || 
                cmb_Answer2.SelectedIndex == -1 || 
                cmb_Answer3.SelectedIndex == -1 || 
                cmb_Answer4.SelectedIndex == -1)
            {
                MessageBox.Show("Please enter all answers", 
                    "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            //method for checking and calculating the score
            getScore();

            //activates the alternate matching sequence for matching callnumbers to descriptions
            alternateColumns = !alternateColumns;

            //refreshes the combobox input for user ease-of-use and experience
            cmb_Answer1.Text = "";
            cmb_Answer2.Text = "";
            cmb_Answer3.Text = "";
            cmb_Answer4.Text = "";

        }

        //Checks and calculates score
        public void getScore()
        {
            //responsible for checking alternate matching feature
            if (alternateColumns == false)
            {
                //checks eacha answer to either add 2 points or remove 1 point
                if (listOfAnswers.Contains(lbl_callNum1.Text + " " + cmb_Answer1.Text))
                {
                    MessageBox.Show("Answer 1 is Correct!\n+2 Points :)", 
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 1 is InCorrect!\n-1 Point :(", 
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;
                }

                if (listOfAnswers.Contains(lbl_callNum2.Text + " " + cmb_Answer2.Text))
                {
                    MessageBox.Show("Answer 2 is Correct!\n+2 Points :)", 
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 2 is InCorrect!\n-1 Point :(", 
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;
                }

                if (listOfAnswers.Contains(lbl_callNum3.Text + " " + cmb_Answer3.Text))
                {
                    MessageBox.Show("Answer 3 is Correct!\n+2 Points :)", 
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 3 is InCorrect!\n-1 Point :(", 
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;
                }

                if (listOfAnswers.Contains(lbl_callNum4.Text + " " + cmb_Answer4.Text))
                {
                    MessageBox.Show("Answer 4 is Correct!\n+2 Points :)", 
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 4 is InCorrect!\n-1 Point :(", 
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;

                }

                //displays the users new total points
                lbl_points.Text = "Total Points: " + score;

                //puts into effect the alternate matching columns feature
                prepareDescripToCallNum();

            }
            else if(alternateColumns == true)
            {
                //checks eacha answer to either add 2 points or remove 1 point
                if (listOfAnswers.Contains(cmb_Answer1.Text + " " + lbl_callNum1.Text))
                {
                    MessageBox.Show("Answer 1 is Correct!\n+2 Points :)",
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 1 is InCorrect!\n-1 Point :(",
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;
                }

                if (listOfAnswers.Contains(cmb_Answer2.Text + " " + lbl_callNum2.Text))
                {
                    MessageBox.Show("Answer 2 is Correct!\n+2 Points :)",
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 2 is InCorrect!\n-1 Point :(",
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;
                }

                if (listOfAnswers.Contains(cmb_Answer3.Text + " " + lbl_callNum3.Text))
                {
                    MessageBox.Show("Answer 3 is Correct!\n+2 Points :)",
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 3 is InCorrect!\n-1 Point :(",
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    score--;
                }

                if (listOfAnswers.Contains(cmb_Answer4.Text + " " + lbl_callNum4.Text))
                {
                    MessageBox.Show("Answer 4 is Correct!\n+2 Points :)",
                        "CORRECT!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    score += 2;
                }
                else
                {
                    MessageBox.Show("Answer 4 is InCorrect!\n-1 Point :(",
                        "INCORRECT", MessageBoxButtons.OK, MessageBoxIcon.Error); ;
                    score--;

                }

                //displays the users new total points
                lbl_points.Text = "Total Points: " + score;

                //puts into effect the alternate matching columns feature
                prepareCallNumToDescrip();

            }

        }

        //provides information to help the user understand the UI
        private void btn_help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t How To Play\n" +
                            "======================\n" +
                            "1) Match column A with Column B\n" +
                            "by selecting the options from\n" +
                            "column B via the ComboBox.\n\n" +
                            "2) After you choose your answers;\n" +
                            "click 'Submit Answers' button.\n\n\n" +
                            "\t Game Rules\n" +
                            "======================\n" +
                            "1) For each correct answer you will\n" +
                            "gain two points; for each incorrect\n" +
                            "answer you will lose a point\n\n" +
                            "2) Every turn the questions will\n" +
                            "alternate between matching\n" +
                            "Call-Numbers to Descriptions\n" +
                            "to Descriptions to Call-Numbers.\n\n" +
                            "3) Enjoy! :)",
                "HELP", MessageBoxButtons.OK);//, MessageBoxIcon.Information);
        }
    }
}

