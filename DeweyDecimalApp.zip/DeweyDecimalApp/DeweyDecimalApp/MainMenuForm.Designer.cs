﻿namespace DeweyDecimalApp
{
    partial class MainMenuForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenuForm));
            this.btn_replacingBooks = new System.Windows.Forms.Button();
            this.btn_identifyingAreas = new System.Windows.Forms.Button();
            this.btn_findingCallNumbers = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.lbl_mainheader = new System.Windows.Forms.Label();
            this.lbl_mainsubheader = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_replacingBooks
            // 
            resources.ApplyResources(this.btn_replacingBooks, "btn_replacingBooks");
            this.btn_replacingBooks.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_replacingBooks.Name = "btn_replacingBooks";
            this.btn_replacingBooks.UseVisualStyleBackColor = false;
            this.btn_replacingBooks.Click += new System.EventHandler(this.btn_replacingBooks_Click);
            // 
            // btn_identifyingAreas
            // 
            resources.ApplyResources(this.btn_identifyingAreas, "btn_identifyingAreas");
            this.btn_identifyingAreas.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_identifyingAreas.Name = "btn_identifyingAreas";
            this.btn_identifyingAreas.UseVisualStyleBackColor = false;
            this.btn_identifyingAreas.Click += new System.EventHandler(this.btn_identifyingAreas_Click);
            // 
            // btn_findingCallNumbers
            // 
            resources.ApplyResources(this.btn_findingCallNumbers, "btn_findingCallNumbers");
            this.btn_findingCallNumbers.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_findingCallNumbers.Name = "btn_findingCallNumbers";
            this.btn_findingCallNumbers.UseVisualStyleBackColor = false;
            this.btn_findingCallNumbers.Click += new System.EventHandler(this.btn_findingCallNumbers_Click);
            // 
            // btn_exit
            // 
            resources.ApplyResources(this.btn_exit, "btn_exit");
            this.btn_exit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // lbl_mainheader
            // 
            resources.ApplyResources(this.lbl_mainheader, "lbl_mainheader");
            this.lbl_mainheader.BackColor = System.Drawing.Color.Transparent;
            this.lbl_mainheader.Name = "lbl_mainheader";
            // 
            // lbl_mainsubheader
            // 
            resources.ApplyResources(this.lbl_mainsubheader, "lbl_mainsubheader");
            this.lbl_mainsubheader.BackColor = System.Drawing.Color.Transparent;
            this.lbl_mainsubheader.Name = "lbl_mainsubheader";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Image = global::DeweyDecimalApp.Properties.Resources.thumbnaildewey_25;
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // MainMenuForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DeweyDecimalApp.Properties.Resources.qw_t;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_mainsubheader);
            this.Controls.Add(this.lbl_mainheader);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_findingCallNumbers);
            this.Controls.Add(this.btn_identifyingAreas);
            this.Controls.Add(this.btn_replacingBooks);
            this.Name = "MainMenuForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_replacingBooks;
        private Button btn_identifyingAreas;
        private Button btn_findingCallNumbers;
        private Button btn_exit;
        private Label lbl_mainheader;
        private Label lbl_mainsubheader;
        private PictureBox pictureBox1;
    }
}