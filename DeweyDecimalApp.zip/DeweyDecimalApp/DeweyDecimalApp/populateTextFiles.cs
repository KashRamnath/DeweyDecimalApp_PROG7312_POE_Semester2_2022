﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeweyDecimalApp
{
    //class responsible for checking is the textfiles exist, or if not, create them and populate them with data
    public class populateTextFiles
    {
        public void populate()
        {
            TextFileTopLevel();
            TextFile000();
            TextFile100();
            TextFile200();
            TextFile300();
            TextFile400();
            TextFile500();
            TextFile600();
            TextFile700();
            TextFile800();
            TextFile900();

        }

        //checks if top layer text file exists and if not, populate them
        public void TextFileTopLevel()
        {
            if (File.Exists("toplevel.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("toplevel.txt");

                streamWriter.WriteLine("000 General Knowledge");
                streamWriter.WriteLine("100 Philosophy and Psychology");
                streamWriter.WriteLine("200 Religion");
                streamWriter.WriteLine("300 Social Sciences");
                streamWriter.WriteLine("400 Languages");
                streamWriter.WriteLine("500 Science");
                streamWriter.WriteLine("600 Technology");
                streamWriter.WriteLine("700 Arts and Culture");
                streamWriter.WriteLine("800 Literature");
                streamWriter.WriteLine("900 History and Geography");

                streamWriter.Close();
            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile000()
        {
            if (File.Exists("000.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("000.txt");

                streamWriter.WriteLine("Manuscripts and rare books");
                streamWriter.WriteLine("Manuscripts");
                streamWriter.WriteLine("Block books");
                streamWriter.WriteLine("Incunabula");
                streamWriter.WriteLine("Printed books");
                streamWriter.WriteLine("Books notable for bindings");
                streamWriter.WriteLine("Books notable for illustrations");
                streamWriter.WriteLine("Books notable for ownership or origin");
                streamWriter.WriteLine("Prohibited works, forgeries, and hoaxes");
                streamWriter.WriteLine("Books notable for format");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile100()
        {
            if (File.Exists("100.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("100.txt");

                streamWriter.WriteLine("Metaphysics");
                streamWriter.WriteLine("Ontology");
                streamWriter.WriteLine("No longer used—formerly Methodology");
                streamWriter.WriteLine("Cosmology ");
                streamWriter.WriteLine("Space");
                streamWriter.WriteLine("Time");
                streamWriter.WriteLine("Change");
                streamWriter.WriteLine("Structure");
                streamWriter.WriteLine("Force and energy");
                streamWriter.WriteLine("Number and quantity");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile200()
        {
            if (File.Exists("200.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("200.txt");

                streamWriter.WriteLine("Bible");
                streamWriter.WriteLine("Old Testament (Tanakh)");
                streamWriter.WriteLine("Historical books of Old Testament");
                streamWriter.WriteLine("Poetic books of Old Testament");
                streamWriter.WriteLine("Prophetic books of Old Testament");
                streamWriter.WriteLine("New Testament");
                streamWriter.WriteLine("Gospels and Acts");
                streamWriter.WriteLine("Epistles");
                streamWriter.WriteLine("Revelation (Apocalypse)");
                streamWriter.WriteLine("Apocrypha, pseudepigrapha, and intertestamental works");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile300()
        {
            if (File.Exists("300.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("300.txt");

                streamWriter.WriteLine("Economics");
                streamWriter.WriteLine("Labor economics");
                streamWriter.WriteLine("Financial economics");
                streamWriter.WriteLine("Economics of land and energy");
                streamWriter.WriteLine("Cooperatives");
                streamWriter.WriteLine("Socialism and related systems");
                streamWriter.WriteLine("Public finance");
                streamWriter.WriteLine("International economics");
                streamWriter.WriteLine("Production");
                streamWriter.WriteLine("Macroeconomics and related topics");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile400()
        {
            if (File.Exists("400.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("400.txt");

                streamWriter.WriteLine("Linguistics");
                streamWriter.WriteLine("Writing systems of standard forms of languages");
                streamWriter.WriteLine("Etymology of standard forms of languages");
                streamWriter.WriteLine("Dictionaries of standard forms of languages");
                streamWriter.WriteLine("Phonology and phonetics of standard forms of languages");
                streamWriter.WriteLine("Grammar of standard forms of languages");
                streamWriter.WriteLine("No longer used—formerly Prosody");
                streamWriter.WriteLine("Dialectology and historical linguistics");
                streamWriter.WriteLine("Standard usage (Prescriptive linguistics)");
                streamWriter.WriteLine("Sign languages");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile500()
        {
            if (File.Exists("500.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("500.txt");

                streamWriter.WriteLine("Physics");
                streamWriter.WriteLine("Classical mechanics");
                streamWriter.WriteLine("Fluid mechanics");
                streamWriter.WriteLine("Pneumatics (Gas mechanics)");
                streamWriter.WriteLine("Sound and related vibrations");
                streamWriter.WriteLine("Light and related radiation");
                streamWriter.WriteLine("Heat");
                streamWriter.WriteLine("Electricity and electronics");
                streamWriter.WriteLine("Magnetism");
                streamWriter.WriteLine("Modern physics");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile600()
        {
            if (File.Exists("600.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("600.txt");

                streamWriter.WriteLine("Manufacturing");
                streamWriter.WriteLine("Metalworking processes and primary metal products");
                streamWriter.WriteLine("Iron, steel, other iron alloys");
                streamWriter.WriteLine("Nonferrous metals");
                streamWriter.WriteLine("Lumber processing, wood products, cork");
                streamWriter.WriteLine("Leather and fur processing");
                streamWriter.WriteLine("Pulp and paper technology");
                streamWriter.WriteLine("Textiles");
                streamWriter.WriteLine("Elastomers and elastomer products");
                streamWriter.WriteLine("Other products of specific kinds of materials");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile700()
        {
            if (File.Exists("700.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("700.txt");

                streamWriter.WriteLine("Recreational and performing arts");
                streamWriter.WriteLine("Public performances");
                streamWriter.WriteLine("Stage presentations");
                streamWriter.WriteLine("Indoor games and amusements");
                streamWriter.WriteLine("Indoor games of skill");
                streamWriter.WriteLine("Games of chance");
                streamWriter.WriteLine("Athletic and outdoor sports and games");
                streamWriter.WriteLine("Aquatic and air sports");
                streamWriter.WriteLine("Equestrian sports and animal racing");
                streamWriter.WriteLine("Fishing, hunting, shooting");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile800()
        {
            if (File.Exists("800.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("800.txt");

                streamWriter.WriteLine("German literature and literatures of related languages");
                streamWriter.WriteLine("German poetry");
                streamWriter.WriteLine("German drama");
                streamWriter.WriteLine("German fiction");
                streamWriter.WriteLine("German essays");
                streamWriter.WriteLine("German speeches");
                streamWriter.WriteLine("German letters");
                streamWriter.WriteLine("German humor and satire");
                streamWriter.WriteLine("German miscellaneous writings");
                streamWriter.WriteLine("Other Germanic literatures");

                streamWriter.Close();

            }
        }

        //checks if textfile exists, if not create them and populate it
        public void TextFile900()
        {
            if (File.Exists("900.txt") == false)
            {
                StreamWriter streamWriter = new StreamWriter("900.txt");

                streamWriter.WriteLine("History of South America");
                streamWriter.WriteLine("Brazil");
                streamWriter.WriteLine("Argentina");
                streamWriter.WriteLine("Chile");
                streamWriter.WriteLine("Bolivia");
                streamWriter.WriteLine("Peru");
                streamWriter.WriteLine("Colombia and Ecuador");
                streamWriter.WriteLine("Venezuela");
                streamWriter.WriteLine("Guiana");
                streamWriter.WriteLine("Paraguay and Uruguay");

                streamWriter.Close();

            }
        }
    }
}
