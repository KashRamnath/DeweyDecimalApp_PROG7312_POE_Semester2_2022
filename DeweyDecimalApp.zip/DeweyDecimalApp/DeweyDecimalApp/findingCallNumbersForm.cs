﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeweyDecimalApp
{
    public partial class findingCallNumbersForm : Form
    {
        //declarations
        public int topLevelNumber;
        public int questionNumber;
        public List<string> test = new List<string>(); //stores top-level values
        public List<string> test1 = new List<string>(); //stores 3rd-level values
        public string answer;
        public string userAnswer;
        public string question;
        public bool points;
        public int score = 0;
        public int ques = 1;

        public findingCallNumbersForm()
        {
            InitializeComponent();

            //begins the application
            run();
            
        }

        //orders app method sequence
        public void run()
        {
            generateNumbers(); //generates eandom numbers for displaying the description to user
            populateLists(); //adds the data to memory fo use
            populateCombobox(); //populates the combobox with top-level values
            getAnswer(); //stores correct answer to compare to user's
        }

        //generates random numbers from 0 to 9
        public void generateNumbers()
        {
            Random random = new Random();

            var rand = new Random();

            topLevelNumber = rand.Next(0, 10);
            questionNumber = rand.Next(0, 10);

            test.Clear();

            test1.Clear();

        }

        //populates descriptions into list from textfile
        public void populateLists() 
        {
            test = File.ReadAllLines("toplevel.txt").ToList();

            switch (topLevelNumber)
            {
                case 0:
                    test1 = File.ReadAllLines("000.txt").ToList();
                    break;
                case 1:
                    test1 = File.ReadAllLines("100.txt").ToList();
                    break;
                case 2:
                    test1 = File.ReadAllLines("200.txt").ToList();
                    break;
                case 3:
                    test1 = File.ReadAllLines("300.txt").ToList();
                    break;
                case 4:
                    test1 = File.ReadAllLines("400.txt").ToList();
                    break;
                case 5:
                    test1 = File.ReadAllLines("500.txt").ToList();
                    break;
                case 6:
                    test1 = File.ReadAllLines("600.txt").ToList();
                    break;
                case 7:
                    test1 = File.ReadAllLines("700.txt").ToList();
                    break;
                case 8:
                    test1 = File.ReadAllLines("800.txt").ToList();
                    break;
                case 9:
                    test1 = File.ReadAllLines("900.txt").ToList();
                    break;
            }
        }

        //gets correct answer
        public void getAnswer()
        {
            lbl_question.Text = test1[questionNumber];
            answer = test[topLevelNumber] + " " + test1[questionNumber];
        }

        //adds top-level data to combobox
        public void populateCombobox()
        {
            cmb_userAnswer.Items.Clear();
            foreach(string item in test)
            {
                cmb_userAnswer.Items.Add(item);
            }
        }

        //calculates the uers points
        public void calculatePoints()
        {
            if (points == true) //+5 points if user answers correct
            {
                score += 5;
            }
            else if(points == false) //-3 points if user answers wrong
            {
                score -= 3;

                if(score < 0) //points dont go below 0
                {
                    score = 0;
                }
            }

            lbl_totalScore.Text = "Your Points: " + score;

            cmb_userAnswer.SelectedIndex = -1;

            run(); //process runs again

        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            if (cmb_userAnswer.SelectedIndex == -1) //error handling
            {
                MessageBox.Show("Please enter all answers",
                    "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            question = lbl_question.Text;
            userAnswer = cmb_userAnswer.Text; //gets user answer

            if(userAnswer + " " + question == answer) //if user answer is correct, do this:
            {
                MessageBox.Show("+5 Points! :)", "Correct", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                points = true; //+5 point is allowed

                if(ques < 100) //resets question counter if it goes over 100 otherwuse +1 to guestion counter
                {
                    ques += 1;
                    lbl_ques.Text = "Question " + ques + ": Which top-layer category does the description belong to?";
                }
                else
                {
                    ques = 1;
                }
                
            }
            else //runs if user answers question wrong
            {
                MessageBox.Show("Your answer:      " + userAnswer + " " + question + "\nCorrect answer:  " + answer + "\n\n-3 Points",
                "Incorrect", MessageBoxButtons.OK);//, MessageBoxIcon.Exclamation);
                points = false;

                ques = 1;
                lbl_ques.Text = "Question " + ques + ": Which top-layer category does the description belong to?";
            }

            calculatePoints(); //calculates users new total points

        }

        private void findingCallNumbersForm_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;

            //instantiates the text files class
            populateTextFiles populateTextFiles = new populateTextFiles();
            populateTextFiles.populate();

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenuForm rbf = new MainMenuForm(); //this is the change, code for redirect  
            rbf.ShowDialog();
        }

        //explains to user how to use the application and what the rules are
        private void btn_help_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t How To Play\n" +
                            "======================\n" +
                            "1) A random description of a 3rd\n" +
                            "level entry will be selected and\n" +
                            "displayed.\n" +
                            "2) The user must use the combobox\n" +
                            "to select the top-level class they\n" +
                            "think the description belongs to\n" +
                            "and click the submit button.\n\n" +
                            "\t Game Rules\n" +
                            "======================\n" +
                            "1) When the user answers correctly\n" +
                            "the will gain 5 points, or lose 3\n" +
                            "points if they answer incorrect;\n" +
                            "however, the points will never drop\n" +
                            "below 0.\n" +
                            "2) For every correct answer the\n" +
                            "question counter will increase,\n" +
                            "or revert to 0 if answered wrong.",
                "HELP", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
