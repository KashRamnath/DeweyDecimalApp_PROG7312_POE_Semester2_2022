﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeweyDecimalApp
{
    public partial class replacingBooksForm : Form
    {
        //creates lists to store the generated numbers and the sorted numbers
        public List<double> numbers = new List<double>();
        public List<double> orderedNumbers = new List<double>();

        //declares the users input values
        double answerOne, answerTwo, answerThree, answerFour, answerFive, 
            answerSix, answerSeven, answerEight, answerNine, answerTen;
        
        //sets user points to 0
        int points = 0;

        public replacingBooksForm()
        {
            InitializeComponent();

            
            this.ControlBox = false; //hides control box

            generateRandomNumbers(); //calls method to generate Dewey Decimals
            printRandomNumbers(); //calls method to print generated Dewey Decimal numbers
            order(); //calls method to order the second list into ascending 
            displayPoints(); //calls method to display calculate and display the users points
            populateComboBox(); //calls method to populate the combobox with the generated values
        }

        //Button for closing form
        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Hide(); //hides form
            MainMenuForm mmf = new MainMenuForm(); 
            mmf.ShowDialog(); //redirects user to Main Mwnu page
        }

        //generates Dewey Decimals
        public void generateRandomNumbers()
        {
            Random random = new Random();

            numbers.Clear(); //clears list of previously populated data

            for (int j = 0; j < 10; j++) //Runs code 10 times
            {
                int num = random.Next(0, 999); //generates int
                double dec = random.NextDouble(); //generated decimals for int
                double deweyValue = Convert.ToDouble(num) + Math.Round(dec, 3); //combines for double with 3 decimal places

                numbers.Add(deweyValue); //adds each Dewey to list
            }

        }

        //button that explains the game and UI to user
        private void btn_help_Click(object sender, EventArgs e)
        {
            //explanation
            MessageBox.Show("The list of numbers on the left are Dewey Decimals.\n" +
                "Order the numbers into ascending order by selecting them\n" +
                "in the fields on the right-hand side. Afterwards, click\n" +
                "'Submit' to check your asnwer.\n" +
                "If you're correct you gain 5 points.\n" +
                "If you're incorrect you lose 5 points.\n" +
                "New numbers are generated each turn\n\n" +
                "Use the back button to exit to the main menu page.", 
                "HOW TO PLAY", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //prints the numbers for the user to view
        public void printRandomNumbers()
        {
            listbox_displayRandomNumbers.Items.Clear(); //clears previous listbox

            foreach(double number in numbers) 
            {
                listbox_displayRandomNumbers.Items.Add(number); //displays new set of numbers to listbox

            }
            
        }

        //orders second list to use as answer sheet to check user inputs if correct
        public void order()
        {
            orderedNumbers.Clear(); //clears previous list

            foreach (double number in numbers)
            {
                orderedNumbers.Add(number); // adds values to 2nd list
            }

            orderedNumbers.Sort(); //sorts list into ascending
        }

        //shows user the previous answer if they got it incorrect
        public void printOrderedNumbers()
        {
            //combines list items to one variable
            var message = string.Join(Environment.NewLine, orderedNumbers);

            //prints message to user
            MessageBox.Show("The previous answer was:\n" + message, "Änswer", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        //runs code once form loads
        private void replacingBooksForm_Load(object sender, EventArgs e) {}

        //assigns declared variables user input values
        private void btn_submit_Click(object sender, EventArgs e)
        {
            //exeption handling for empty fields, ' , ' and strings instead of doubles
            try
            {
                //assigns values from user input if no errors encountered
                answerOne = Convert.ToDouble(comboBox1.Text);
                answerTwo = Convert.ToDouble(comboBox2.Text);
                answerThree = Convert.ToDouble(comboBox3.Text);
                answerFour = Convert.ToDouble(comboBox4.Text);
                answerFive = Convert.ToDouble(comboBox5.Text);
                answerSix = Convert.ToDouble(comboBox6.Text);
                answerSeven = Convert.ToDouble(comboBox7.Text);
                answerEight = Convert.ToDouble(comboBox8.Text);
                answerNine = Convert.ToDouble(comboBox9.Text);
                answerTen = Convert.ToDouble(comboBox10.Text);

            }
            catch (Exception)
            {
                //notifies user how to avoid errors
                MessageBox.Show("Please ensure:\n" +
                    "1) appropriate values are entered\n" +
                    "2) fields are not empty\n" +
                    "3) ' , ' instead of ' . ' is used", 
                    "Invalid Inputs", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                //generates new values and repopulates comboboxes
                generateRandomNumbers();
                order();
                printRandomNumbers();
                printOrderedNumbers();
                populateComboBox();
                return; //terminates

            }

            result(); //calculates user points
            generateRandomNumbers(); //regenereates Deweys
            order(); //reorders 2nd list
            printRandomNumbers(); //reprints new generated Deweys
            populateComboBox(); //repopulates combo boxes for user
        }

        //checks if users answer is correct or incorrect
        public void result()
        {
            //if user is correct, display correct and calculate points
            if (answerOne == orderedNumbers[0] &&
                answerTwo == orderedNumbers[1] &&
                answerThree == orderedNumbers[2] &&
                answerFour == orderedNumbers[3] &&
                answerFive == orderedNumbers[4] &&
                answerSix == orderedNumbers[5] &&
                answerSeven == orderedNumbers[6] &&
                answerEight == orderedNumbers[7] &&
                answerNine == orderedNumbers[8] &&
                answerTen == orderedNumbers[9])
            {
                MessageBox.Show("You Answered Correctly! ;)\n+5 Points!",
                    "Correct!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                points = points + 5; //adds to points

                displayPoints(); //pisplay points
            }
            else //if user is incorrect, display incorrect and calculate points
            {
                MessageBox.Show("You Answered Incorrectly :(\n-5 Points...",
                    "Incorrect!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                points = points - 5; //subtracts points

                displayPoints(); //display points

                printOrderedNumbers(); //shows user the previous answer
            }

        }

        //repopulates combobox for user ease of use
        public void populateComboBox ()
        {
            //deselects previously selcted inputs
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;
            comboBox4.SelectedIndex = -1;
            comboBox5.SelectedIndex = -1;
            comboBox6.SelectedIndex = -1;
            comboBox7.SelectedIndex = -1;
            comboBox8.SelectedIndex = -1;
            comboBox9.SelectedIndex = -1;
            comboBox10.SelectedIndex = -1;

            //clears combobox items
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();
            comboBox4.Items.Clear();
            comboBox5.Items.Clear();
            comboBox6.Items.Clear();
            comboBox7.Items.Clear();
            comboBox8.Items.Clear();
            comboBox9.Items.Clear();
            comboBox10.Items.Clear();

            foreach(double number in numbers)
            {
                //repopulates combobox with new values
                comboBox1.Items.Add(number);
                comboBox2.Items.Add(number);
                comboBox3.Items.Add(number);
                comboBox4.Items.Add(number);
                comboBox5.Items.Add(number);
                comboBox6.Items.Add(number);
                comboBox7.Items.Add(number);
                comboBox8.Items.Add(number);
                comboBox9.Items.Add(number);
                comboBox10.Items.Add(number);
            }

        }

        //displays and updates points to the user
        public void displayPoints()
        {
            if(points < 0) //ensures points doesnt go below 0
            { 
                points = 0;
            }
            else 
            { 
                lbl_points.Text = "Your Points: " + points; 
            }

        }

        //mistake
        private void label5_Click(object sender, EventArgs e){}

    }
}
