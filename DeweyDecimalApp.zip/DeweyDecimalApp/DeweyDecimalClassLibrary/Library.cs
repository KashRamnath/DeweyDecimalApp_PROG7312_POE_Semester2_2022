﻿namespace DeweyDecimalClassLibrary
{
    public class Library
    {
        public List<string> callNumber = new List<string>();
        public List<string> description = new List<string>();
        public List<string> answers = new List<string>();

        //public Dictionary<int, string> keyValuePairs = new Dictionary<int, string>();

        public Library()
        {
            //keyValuePairs.Add(000, "General Knowledge");
            //keyValuePairs.Add(100, "Philosophy and Psychology");
            //keyValuePairs.Add(200, "Religion");
            //keyValuePairs.Add(300, "Social Sciences");
            //keyValuePairs.Add(400, "Languages");
            //keyValuePairs.Add(500, "Science");
            //keyValuePairs.Add(600, "Technology");
            //keyValuePairs.Add(700, "Arts and Culture");
            //keyValuePairs.Add(800, "Literature");
            //keyValuePairs.Add(900, "History and Geography");

            //foreach(KeyValuePair<int,string> kv in keyValuePairs)
            //{
            //    Console.WriteLine(kv.Key+" "+kv.Value.ToString());
            //}

            callNumber.Add("000");
            callNumber.Add("100");
            callNumber.Add("200");
            callNumber.Add("300");
            callNumber.Add("400");
            callNumber.Add("500");
            callNumber.Add("600");
            callNumber.Add("700");
            callNumber.Add("800");
            callNumber.Add("900");

            description.Add("General Knowlege");
            description.Add("Philosophy and Psychology");
            description.Add("Religion");
            description.Add("Social Sciences");
            description.Add("Languages");
            description.Add("Science");
            description.Add("Technology");
            description.Add("Arts and Culture");
            description.Add("Literature");
            description.Add("History and Geography");

            answers.Add("000 General Knowlege");
            answers.Add("100 Philosophy and Psychology");
            answers.Add("200 Religion");
            answers.Add("300 Social Sciences");
            answers.Add("400 Languages");
            answers.Add("500 Science");
            answers.Add("600 Technology");
            answers.Add("700 Arts and Culture");
            answers.Add("800 Literature");
            answers.Add("900 History and Geography");

        }

    }
}